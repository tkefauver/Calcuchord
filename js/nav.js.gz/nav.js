function openLink(url) {
    window.open(url);
}